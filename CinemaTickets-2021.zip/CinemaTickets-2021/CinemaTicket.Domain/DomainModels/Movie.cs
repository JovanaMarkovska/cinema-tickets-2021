﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaTicket.Domain.DomainModels
{
    public class Movie : BaseEntity
    {
        public string Name { get; set; }
        public string Genre { get; set; }
        public virtual ICollection<Ticket> Tickets { get; set; }
    }
}
