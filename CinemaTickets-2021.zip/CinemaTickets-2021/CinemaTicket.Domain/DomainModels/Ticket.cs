﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaTicket.Domain.DomainModels
{
    public class Ticket : BaseEntity
    {
        public int Price { get; set; }
        public DateTime Date { get; set; }
        public Movie Movie { get; set; }
        public Guid MovieId { get; set; }
        public virtual ICollection<TicketInShoppingCart> TicketInShoppingCart { get; set; }
        public virtual ICollection<TicketsInOrder> Orders { get; set; }

    }
}
