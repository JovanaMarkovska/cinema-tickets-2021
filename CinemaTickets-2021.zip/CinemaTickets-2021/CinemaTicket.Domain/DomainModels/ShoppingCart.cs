﻿using CinemaTicket.Domain.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaTicket.Domain.DomainModels
{
    public class ShoppingCart : BaseEntity
    {
        public string OwnerId { get; set; }
        public virtual CinemaTicketsUser Owner { get; set; }
        public int TotalPrice { get; set; }
        public virtual ICollection<TicketInShoppingCart> TicketInShoppingCart { get; set; }

    }
}
