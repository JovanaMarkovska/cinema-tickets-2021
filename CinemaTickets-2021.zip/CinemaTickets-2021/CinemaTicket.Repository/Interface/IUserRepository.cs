﻿using CinemaTicket.Domain.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace CinemaTicket.Repository.Interface
{
    public interface IUserRepository
    {
        IEnumerable<CinemaTicketsUser> GetAll();
        CinemaTicketsUser Get(string id);
        void Insert(CinemaTicketsUser entity);
        void Update(CinemaTicketsUser entity);
        void Delete(CinemaTicketsUser entity);
    }
}
