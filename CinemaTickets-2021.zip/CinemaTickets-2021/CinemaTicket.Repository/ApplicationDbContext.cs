﻿using System;
using System.Collections.Generic;
using System.Text;
using CinemaTicket.Domain.DomainModels;
using CinemaTicket.Domain.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CinemaTicket.Repository
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<Movie> Movies { get; set; }
        public virtual DbSet<Ticket> Tickets { get; set; }
        public virtual DbSet<ShoppingCart> ShoppingCarts { get; set; }
        public virtual DbSet<TicketInShoppingCart> TicketsInShoppingCarts { get; set; }

        protected override void OnModelCreating(ModelBuilder migrationBuilder)
        {
            base.OnModelCreating(migrationBuilder);

            migrationBuilder.Entity<Ticket>()
                .Property(z => z.Id)
                .ValueGeneratedOnAdd();

            migrationBuilder.Entity<Movie>()
                .Property(z => z.Id)
                .ValueGeneratedOnAdd();

            migrationBuilder.Entity<ShoppingCart>()
                .Property(z => z.Id)
                .ValueGeneratedOnAdd();

            migrationBuilder.Entity<ShoppingCart>()
                .HasOne<CinemaTicketsUser>(z => z.Owner)
                .WithOne(z => z.UserCart)
                .HasForeignKey<ShoppingCart>(z => z.OwnerId);

            migrationBuilder.Entity<Movie>()
                   .HasMany(c => c.Tickets)
                   .WithOne(e => e.Movie);

            migrationBuilder.Entity<Ticket>()
                .HasOne(e => e.Movie)
                .WithMany(c => c.Tickets);

            migrationBuilder.Entity<TicketInShoppingCart>()
                 .HasKey(z => new { z.TicketId, z.ShoppingCartId });

            migrationBuilder.Entity<TicketInShoppingCart>()
                    .HasOne(z => z.Ticket)
                    .WithMany(z => z.TicketInShoppingCart)
                    .HasForeignKey(z => z.ShoppingCartId);

            migrationBuilder.Entity<TicketInShoppingCart>()
                   .HasOne(z => z.ShoppingCart)
                   .WithMany(z => z.TicketInShoppingCart)
                   .HasForeignKey(z => z.TicketId);

            migrationBuilder.Entity<ShoppingCart>()
                .HasOne<CinemaTicketsUser>(z => z.Owner)
                .WithOne(z => z.UserCart)
                .HasForeignKey<ShoppingCart>(z => z.OwnerId);

            migrationBuilder.Entity<TicketsInOrder>()
                .HasKey(z => new { z.TicketId, z.OrderId });

            migrationBuilder.Entity<TicketsInOrder>()
               .HasOne(z => z.SelectedTicket)
               .WithMany(z => z.Orders)
               .HasForeignKey(z => z.TicketId);

            migrationBuilder.Entity<TicketsInOrder>()
              .HasOne(z => z.UserOrder)
              .WithMany(z => z.TicketsInOrder)
              .HasForeignKey(z => z.OrderId);







        }
    }
}
